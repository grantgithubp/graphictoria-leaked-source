<?php 
//file_put_contents($_SERVER["DOCUMENT_ROOT"]."/SiT_3/connections.txt",$_SERVER['REMOTE_ADDR']."\n", FILE_APPEND | LOCK_EX);

     // die("This website has temporarily shut down. We'll be back soon enough. -Anarchy");

$conn = mysqli_connect( "mysql2.serv00.com" , "m1170_gtoria2", "Kara3931@" , "m1170_gtoria2");
  if(!$conn) {
    //include("site/maint.php");
    die("Database Error");
  }
  
  //sorry, but every page should require a session -lukey
  if(session_status() == PHP_SESSION_NONE) {
    session_name("BRICK-SESSION");
    session_start();
  }
?>