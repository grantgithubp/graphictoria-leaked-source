<?php
    
    
    include("config.php");
    
    
    $offline = false;
    $sitename = "Graphictoria";
    $sitelink = "https://gtoria.com";
    
?>


