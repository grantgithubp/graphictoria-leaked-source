<?php
if($loggedIn) {
echo '
   <div class="headernav">
      <span style="vertical-align: middle; line-height: 30px; ">
                              <a href="/customize/">Avatar</a> |  <a href="/user/'. $userRow->{'id'}.'/">Profile</a> | <a href="/settings/">Settings</a> | <a href="/friends/">Friends</a> | <a href="/messages/">Messages</a>
</span>
</div>
';
  }
?>
