<footer>
<div>©️ 2022 Brick Hill. All rights reserved.</div>
<a href="/terms">Terms of Service</a> | <a href="/privacy">Privacy Policy</a> | <a href="/staff">Staff</a>
</footer>