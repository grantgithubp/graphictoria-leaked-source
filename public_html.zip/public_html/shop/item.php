<?php
include("../SiT_3/config.php");
include("../SiT_3/header.php");
include("../SiT_3/PHP/helper.php");
//if(!$loggedIn) {header("Location: /index"); die();}
if($loggedIn) {
  $userID = $_SESSION['id'];
  $userSQL = "SELECT * FROM `beta_users` WHERE `id`='$userID'";
  $user = $conn->query($userSQL);
  $currentUserRow = $user->fetch_assoc();
}

if (isset($_GET['id'])) {
  $itemID = mysqli_real_escape_string($conn,intval($_GET['id']));
  $sql = "SELECT * FROM `shop_items` WHERE  `id` = '$itemID'";
  $result = $conn->query($sql);
  $shopRow = $searchRow=$result->fetch_assoc();
  if($_GET['id'] == $shopRow['id']) {} else {echo"<script>location.replace('/shop/');</script>";}
    //header('Location: /shop/');}
  $id = $searchRow['owner_id'];
  $sqlUser = "SELECT * FROM `beta_users` WHERE  `id` = '$id'";
  $userResult = $conn->query($sqlUser);
  $userRow=$userResult->fetch_assoc();
} else {
  //echo"<script>location.replace('/shop/');</script>";
  header('Location: /shop/');
}

if($loggedIn) {
  if (isset($_GET['approve']) && $currentUserRow['power'] >= 1) {
    $approveSQL = "UPDATE `shop_items` SET `approved`='yes' WHERE `id`='$itemID'";
    $approve = $conn->query($approveSQL);
    //echo'<script>location.replace("/shop/item/'.$itemID.'");</script>';
    header('Location: /shop/item/'.$itemID.'');
  }
  if (isset($_GET['decline']) && $currentUserRow['power'] >= 1) {
    $declineSQL = "UPDATE `shop_items` SET `approved`='declined' WHERE `id`='$itemID'";
    $decline = $conn->query($declineSQL);
    //echo'<script>location.replace("/shop/item/'.$itemID.'");</script>';
    //header('Location: item?id='.$itemID);
    header('Location: /shop/item/'.$itemID.'');
  }
  if (isset($_GET['desc']) && $currentUserRow['power'] >= 2) {
    $scrubSQL = "UPDATE `shop_items` SET `description`='[Content Removed]' WHERE `id`='$itemID'";
    $scrub = $conn->query($scrubSQL);
    
    $scrubSQL = "UPDATE `shop_items` SET `title`='[Content Removed]' WHERE `id`='$itemID'";
    $scrub = $conn->query($scrubSQL);
    //header('Location: item?id='.$itemID);
    //echo'<script>location.replace("/shop/item/'.$itemID.'");</script>';
    header('Location: /shop/item/'.$itemID.'');
  }
  if (isset($_GET['scrub_comment']) && $currentUserRow['power'] >= 2) {
    $comID = mysqli_real_escape_string($conn,intval($_GET['scrub_comment']));
    $scrubSQL = "UPDATE `item_comments` SET `comment`='[Content Removed]' WHERE  `id`='$comID'";
    $scrub = $conn->query($scrubSQL);
    //echo'<script>location.replace("/shop/item/'.$itemID.'");</script>';
    header('Location: /shop/item/'.$itemID.'');
  }
}

if ($shopRow['approved'] == 'yes') {$thumbnail = $searchRow['id'];}
elseif ($shopRow['approved'] == 'declined') {$thumbnail = 'declined';}
else {$thumbnail = 'pending';}

$soldSQL = "SELECT * FROM `crate` WHERE `item_id` = '$itemID' AND `user_id` !='$id' AND `own`='yes'";
$soldResult = $conn->query($soldSQL);
$amountSold = $soldResult->num_rows;

$realSoldSQL = "SELECT * FROM `crate` WHERE `item_id` = '$itemID' AND `own`='yes'";
$realSoldResult = $conn->query($realSoldSQL);
$realAmountSold = $realSoldResult->num_rows;

if($loggedIn) {
$currentUserID = $_SESSION['id'];
} else {
$currentUserID = 0;
}
$ownsSQL = "SELECT * FROM `crate` WHERE `item_id`='$itemID' AND `user_id`='$currentUserID'";
$owns = $conn->query($ownsSQL);
if($owns->num_rows > 0) {$owns = true;} else {$owns = false;}

if($loggedIn && (isset($_POST['buyBucks']) || isset($_POST['buyBits']) || isset($_POST['buyFree']))) { //if they sent a buy request

  $serialSQL = "SELECT * FROM `crate` WHERE `item_id`='$itemID' ORDER BY `serial` DESC"; //find the serial SQL
  $serialQ = $conn->query($serialSQL); //
  $serialRow = $serialQ->fetch_assoc(); //
  $serial = $serialRow['serial']+1; //find the serial
  
  $currentUserSQL = "SELECT * FROM `beta_users` WHERE `id`='$currentUserID'";
  $currentUser = $conn->query($currentUserSQL);
  $currentRow = $currentUser->fetch_assoc();
  
  if(isset($_POST['buyBucks'])) {$type = 'bucks'; $price = $shopRow['bucks'];}
  if(isset($_POST['buyBits'])) {$type = 'bits'; $price = $shopRow['bits'];}
  if(isset($_POST['buyFree'])) {$type = 'bits'; $price = '0';}
  
  $buySQL = "INSERT INTO `crate` (`id`,`user_id`,`item_id`,`serial`,`payment`,`price`) VALUES (NULL,'$currentUserID','$itemID','$serial','$type','$price')"; //get ready to give item
  
  
  $newBucks = $currentRow['bucks']-$shopRow['bucks']; //take bucks from customer
  $newBucksSQL = "UPDATE `beta_users` SET `bucks`='$newBucks' WHERE `id`='$currentUserID'"; //prep query for taking bucks
  $sellerBucks = $userRow['bucks']+(int)($shopRow['bucks']*0.8); //give bucks to seller 80% tax
  $sellerBucksSQL = "UPDATE `beta_users` SET `bucks`='$sellerBucks' WHERE `id`='$id'"; //prep query for giving bucks
  
  
  $newBits = $currentRow['bits']-$shopRow['bits']; //take bits from customer
  $newBitsSQL = "UPDATE `beta_users` SET `bits`='$newBits' WHERE `id`='$currentUserID'"; //prep query for taking bits
  $sellerBits = $userRow['bits']+(int)($shopRow['bits']*0.8); //give bits to seller 80% tax
  $sellerBitsSQL = "UPDATE `beta_users` SET `bits`='$sellerBits' WHERE `id`='$id'"; //prep query for giving bits
  

  if(!($owns)) {
    if($shopRow['collectible'] == 'yes') { //if it is a collectible
      if($amountSold >= $shopRow['collectible_q']) { //if it's out of still in stock
        //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=stock");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=stock');
      }
    }
    
    if(isset($_POST['buyFree'])) { //if they tried to buy it for free
      if($shopRow['bucks'] == 0 || $shopRow['bits'] == 0) { //if it is indeed free
        $buy = $conn->query($buySQL);
        //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=success");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=success');
      } else {
        //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=error");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=error');
      }
    }
    elseif(isset($_POST['buyBucks'])) { //tried to buy for bucks
      if($currentRow['bucks'] >= $shopRow['bucks'] && $shopRow['bucks'] > 0) { //check they have enough bucks AND if it was on sale for bucks
        $buy = $conn->query($buySQL);
        $newBucksQ = $conn->query($newBucksSQL);
        $sellerBucksQ = $conn->query($sellerBucksSQL);
       //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=success");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=success');
      } else {
        //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=error");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=money');
      }
    }
    elseif(isset($_POST['buyBits'])) { //tried to buy for bucks
      if($currentRow['bits'] >= $shopRow['bits'] && $shopRow['bits'] > 0) { //check they have enough bucks AND if it was on sale for bucks
        $buy = $conn->query($buySQL);
        $newBitsQ = $conn->query($newBitsSQL);
        $sellerBitsQ = $conn->query($sellerBitsSQL);
      //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=success");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=success');
      } else {
        //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=error");</script>';
        header('Location: /shop/item/'.$itemID.'&msg=money');
      }
    }
  } else {
    //echo'<script>location.replace("/shop/item/'.$itemID.'&msg=have");</script>';
    header('Location: /shop/item/'.$itemID.'&msg=have');
  }
}


if($loggedIn && isset($_POST['sell'])) {
  $bucks = mysqli_real_escape_string($conn,intval($_POST['sell']));

  $crateSQL = "SELECT * FROM `crate` WHERE `item_id`='$itemID' AND `user_id`='$currentUserID' AND `own`='yes'";
  $crate = $conn->query($crateSQL);
  
  $sellSQL = "SELECT * FROM `special_sellers` WHERE `item_id`='$itemID' AND `user_id`='$currentUserID' AND `active`='yes'";
  $sell = $conn->query($sellSQL);
  
  if($crate->num_rows > $sell->num_rows && $bucks >= 1) {
    $crateRow = $crate->fetch_assoc();
    $serial = $crateRow['serial'];
    $listSQL = "INSERT INTO `special_sellers` (`id`,`user_id`,`item_id`,`serial`,`bucks`,`active`) VALUES (NULL,'$currentUserID','$itemID','$serial','$bucks','yes')";
    $list = $conn->query($listSQL);
  }
  
  header("Location: /shop/item/".$itemID);
  //echo'<script>location.replace("/shop/item/'.$itemID.'");</script>';
}
if($loggedIn && isset($_POST['remove'])) {
  $sale = mysqli_real_escape_string($conn,intval($_POST['sale']));
  
  $currentUserSQL = "SELECT * FROM `beta_users` WHERE `id`='$currentUserID'";
  $currentUser = $conn->query($currentUserSQL);
  $currentRow = $currentUser->fetch_assoc();
  
  $sellSQL = "SELECT * FROM `special_sellers` WHERE `active`='yes'";
  $sell = $conn->query($sellSQL);
  $sellRow = $sell->fetch_assoc();
  
  if($currentRow['id'] == $sellRow['user_id']) {
    $updateSaleSQL = "UPDATE `special_sellers` SET `active`='no' WHERE `id`='$sale'";
    $updateSale = $conn->query($updateSaleSQL);
  }
  header("Location: /shop/item/".$itemID);
  //echo'<script>location.replace("/shop/item/'.$itemID.'");</script>';
}

if($loggedIn && isset($_POST['buySale'])) { ///NOT TESTED YET
  $sale = mysqli_real_escape_string($conn,intval($_POST['buySale']));
  
  $currentUserSQL = "SELECT * FROM `beta_users` WHERE `id`='$currentUserID'";
  $currentUser = $conn->query($currentUserSQL);
  $currentRow = $currentUser->fetch_assoc();
  
  $sellSQL = "SELECT * FROM `special_sellers` WHERE `id`='$sale'";
  $sell = $conn->query($sellSQL);
  $sellRow = $sell->fetch_assoc();
  
  $bucks = $sellRow['bucks'];
  if($sellRow['user_id'] != $_SESSION['id'] && $bucks <= $currentRow['bucks'] && $sellRow['active'] == 'yes') {
    $newBucks = $currentRow['bucks']-$bucks;
    
    $updateSaleSQL = "UPDATE `special_sellers` SET `active`='no' WHERE `id`='$sale'";
    $updateSale = $conn->query($updateSaleSQL);
    
    $sellerID = $sellRow['user_id'];
    $sellItemID = $sellRow['item_id'];
    $sellSerial = $sellRow['serial'];
    
    $sellerSQL = "SELECT * FROM `beta_users` WHERE `id`='$sellerID'";
    $seller = $conn->query($sellerSQL);
    $sellerRow = $seller->fetch_assoc();
    $sellerBucks = $sellerRow['bucks']+round(0.8*$bucks);
    
    $removeSQL = "UPDATE `crate` SET `own`='no' WHERE `user_id`='$sellerID' AND `item_id`='$sellItemID' AND `serial`='$sellSerial'";
    $remove = $conn->query($removeSQL);
    
    $addSQL = "INSERT INTO `crate` (`id`,`user_id`,`item_id`,`serial`,`payment`,`price`) VALUES (NULL,'$currentUserID','$sellItemID','$sellSerial','bucks','$bucks')";
    $add = $conn->query($addSQL);
    
    $newSellerMoneySQL = "UPDATE `beta_users` SET `bucks`='$sellerBucks' WHERE `id`='$sellerID'";
    $newSellerMoney = $conn->query($newSellerMoneySQL);
    $newBuyerMoneySQL = "UPDATE `beta_users` SET `bucks`='$newBucks' WHERE `id`='$currentUserID'";
    $newBuyerMoney = $conn->query($newBuyerMoneySQL);
  }
}

?>




<!DOCTYPE html>
  <head>
    <title><?php echo htmlentities($shopRow['name']); ?> -  <?php echo $sitename; ?></title>
  </head>
  <body>
    <div id="body">
    
    <?php
  if(isset($_GET['msg'])){
    $msg = $_GET['msg'];
    if($msg == "money"){
      echo "<h5 style='text-align:center; background-color:red; color:white; margin-top:5px; margin-left: 0px; margin-right: 0px; padding-top: 5px; padding-bottom: 5px;'>You dont have enough money to buy $shopRow[name].</h5>";
    } elseif ($msg == "have") {
      ?>    <div class="col-10-12 push-1-12">
<div class="alert error">
You already own <?=$shopRow['name']?>
      </div>
</div><?php
    } elseif ($msg == "stock"){
      echo "<h5 style='text-align:center;background-color:red;color:white;margin-top:5px; margin-left: 0px; margin-right: 0px; padding-top: 5px; padding-bottom: 5px;'>This item is out of stock.</h5>";
    } elseif ($msg == "success") {
      ?><div class="col-10-12 push-1-12">
<div class="alert success">
<?=$shopRow['name']?> has been successfully purchased!
      </div>
</div><?php
    } elseif ($msg == "error") {
      echo "<h5 style='text-align:center;background-color:green;color:white;margin-top:5px; margin-left: 0px; margin-right: 0px; padding-top: 5px; padding-bottom: 5px;'>An unknown error occurred.</h5>";
    }
  }
    ?><br><br><br>
      <section class="section">
<div class="container">
<div class="columns">
<div class="column is-2"></div>
<div class="column is-9">
<div class="containergrey_nopadding item_container">
  <h4 class="banner_title"></h4><br>
  <div style="padding-right: 30px; padding-left: 30px; padding-bottom: 30px;overflow: hidden;">
    <div style="position:relative;" class="item_thumbnail">
<?php echo'<div class="box relative shaded item-img ';if($shopRow['collectable-edition'] == 'yes'){echo'special';} elseif($shopRow['collectible'] == 'yes'){echo'special';} echo'">';?>
          <?php
          if(isset($_GET['render']) && ($shopRow['owner_id'] == $_SESSION['id'] || $currentUserRow['power'] >= 1)) {
            echo '<iframe style="background-color:#FFF;float:left;border:1px #c3cdd2 solid;width:340px;height:340px;" src="/avatar/render/shop_render?id='.$shopRow['id'].'"></iframe>';
          }
  if(isset($_GET['hatrender']) && ($shopRow['owner_id'] == $_SESSION['id'] || $currentUserRow['power'] >= 1)) {
            echo '<iframe style="background-color:#FFF;float:left;border:1px #c3cdd2 solid;width:340px;height:340px;" src="/avatar/render/hat?id='.$shopRow['id'].'"></iframe>';
          }
  if(isset($_GET['toolrender']) && ($shopRow['owner_id'] == $_SESSION['id'] || $currentUserRow['power'] >= 1)) {
            echo '<iframe style="background-color:#FFF;float:left;border:1px #c3cdd2 solid;width:340px;height:340px;" src="/avatar/render/hat?id='.$shopRow['id'].'"></iframe>';
          }
  if(isset($_GET['headrender']) && ($shopRow['owner_id'] == $_SESSION['id'] || $currentUserRow['power'] >= 1)) {
            echo '<iframe style="background-color:#FFF;float:left;border:1px #c3cdd2 solid;width:340px;height:340px;" src="/avatar/render/head?id='.$shopRow['id'].'"></iframe>';
          }
if(isset($_GET['frender']) && ($shopRow['owner_id'] == $_SESSION['id'] || $currentUserRow['power'] >= 1)) {
            echo '<iframe style="background-color:#FFF;float:left;border:1px #c3cdd2 solid;width:340px;height:340px;" src="/avatar/render/face?id='.$shopRow['id'].'"></iframe>';
          }
if(isset($_GET['srender']) && ($shopRow['owner_id'] == $_SESSION['id'] || $currentUserRow['power'] >= 1)) {
            echo '<iframe style="background-color:#FFF;float:left;border:1px #c3cdd2 solid;width:340px;height:340px;" src="/avatar/render/srender?id='.$shopRow['id'].'"></iframe>';
          }

//trender got removed due to it is being useless

          else {
            echo '<img id="shopItem" style="width:250px;vertical-align: middle;" src="/shop_storage/thumbnails/'.$thumbnail.'.png?c='. rand() .'"';
            if($shopRow['collectable-edition'] == 'yes'){echo 'background-image:url(http://epic.ct8.pl/shop/speciale_big.png); background-size:cover; border:0px; width:342px; height:342px;';}
            elseif($shopRow['collectible'] == 'yes'){echo 'background-image:url(http://epic.ct8.pl/shop/special_big.png); background-size:cover;border:0px; width:342px; height:342px;';}
            elseif($shopRow['bits'] == '0' || $shopRow['bucks'] == '0'){echo 'background-image:url(http://epic.ct8.pl/shop/free_big.png); background-size:cover;border:0px; width:350px; height:350px;';}
            echo '">';
          }
            ?>
</div>
</div>
<div class="col-7-12 item-data">
<div class="padding-bottom">
<div class="ellipsis">
<?php
          if($loggedIn) {
            echo '
<dropdown id="dropdown-v" class="dropdown" style="right:7.5px;">
<ul>';?>

<?php if($shopRow['owner_id'] == $_SESSION['id'] or $currentUserRow['power'] >= 1) {
              echo '<li>
<a href="/shop/edit/'.$shopRow['id'].'">Edit</a>
</li>
<li>
<a href="/shop/item/'.$shopRow['id'].'&render">Render</a>
</li>';
  }
  ?>
  
  <?php if($shopRow['approved'] != 'yes' && $currentUserRow['power'] >= 1) {
              echo '<li>
<a href="/shop/item/'.$shopRow['id'].'&approve">Approve</a>
</li>';
  }
if($currentUserRow['power'] >= 1) {
              echo '
<li>
<a href="/shop/item/'.$shopRow['id'].'&decline">Decline</a>
</li>';
  }
  
  ?>
<?php echo'<li>
<a href="/report?type=item&id='.$shopRow['id'].'">Report</a>
</li>';
  ?>
</ul>
</dropdown>
  <?php
  }
    ?>
        <?php
          echo '<span class="medium-text bold ablack-text">' . htmlentities($shopRow['name']).'</span><span> '.$shopRow['type'].'</span>

</div>
<div class="item-creator">
By
<a href="/user/'.$userRow['id'].'/">'.$userRow['username'].'</a>' ;
          
            if ($loggedIn) {
      if ($power > 3) {
        echo '<span style="font-size:15px;">('.shopItemHash($shopRow['id']).')</span>';
      }
    }
      echo '</h3>';
        ?>
  <span style="display:inline-block; float:left; width:640px;">
          <?php
            if ($shopRow['collectible'] == 'yes' || $shopRow['collectable-edition'] == 'yes') {
              $remaining = $shopRow['collectible_q']-$realAmountSold;
              echo "<span style=";
              if($remaining > 0) {echo 'font-weight:bold;';}
              echo "display:block;color:red;'><br>";
              echo $remaining." out of ".$shopRow['collectible_q']." remaining</span>";
            } else {$remaining = 1;}
            
            if($remaining > 0 ) {
      if ($shopRow['bucks'] == 0 || $shopRow['bits'] == 0) {
        echo "<span style='display:inline-block;'>
          <br>
                    <form method='post' action=''>
            <button type='submit' name='buyFree' class='BigButton g-recaptcha'>FREE</button>
          </form>
        </span>";
      }
      
      if ($shopRow['bucks'] >= 1) {
        echo " ";
      }
      
      if ($shopRow['bits'] >= 1) {
        echo "<span style='display:inline-block;''> </a>
          <br>
          <form method='post' action=''>
           <button type='submit' name='buyBits' class='BigButton g-recaptcha'>
       $shopRow[bits] tix
    </button>
          </form>
        </span>";
      }
    }
            
          ?>
</div>
          <div class="padding-10"></div>
<div class="agray-text bold">
<?php echo str_replace("\n","<br>",str_replace("<","<",str_replace(">","&gt;",$shopRow['description']))); ?>
 <?php
    if($loggedIn) {
      if($power >= 2) {
        echo '<p><span><a class="label" href="item?id='.$shopRow['id'].'&desc">Scrub</a></span></p>';
      }
    }
    ?>
 </div>
<div class="padding-30"></div>
<div class="small-text mt6 mb2">
<div class="item-stats">
<span class="agray-text">Created:</span>
<span class="darkest-gray-text" title="<?php echo'' . gmdate('d/m/Y',strtotime($shopRow['date'])) . '';?>">
<?php echo'' . gmdate('d/m/Y',strtotime($shopRow['date'])) . '';?></span>
</div>
<div class="item-stats">
<span class="agray-text">Updated:</span>
<span class="darkest-gray-text" title="<?php echo'' . gmdate('d/m/Y',strtotime($shopRow['last_updated'])) . ''; ?>">
<?php
 echo'' . gmdate('d/m/Y',strtotime($shopRow['last_updated'])) . ''; ?>
</span>
</div>
<div class="item-stats">
<span class="agray-text">Sold:</span>
<span class="darkest-gray-text">
<?php echo $amountSold; ?>
</span>
</div>
</div>
   </div>
<hr>
<section>
