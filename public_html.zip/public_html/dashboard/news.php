<?php
  include("../SiT_3/config.php");
//experimental thing, please do not fuck it up

  //include("../SiT_3/ahdr.php");
  
  $forumID = "";
  
  if(isset($_GET['page'])) {$page = mysqli_real_escape_string($conn,intval($_GET['page']));} else {$page = 0;}
  $page = max($page,1);
  
  $sqlCount = "SELECT * FROM `forum_threads` WHERE `board_id` = '$forumID' AND `deleted` = 'no'";
  $countQ = $conn->query($sqlCount);
  $count = $countQ->num_rows;
  
  
  $sqlPosts = "SELECT * FROM `forum_threads` WHERE `deleted` = 'no' AND `pinned` = 'no' AND `locked` = 'no' ORDER BY `pinned` ASC, `id` DESC LIMIT 6";
  $postsResult = $conn->query($sqlPosts);
  
?>
<?php
            while($postRow=$postsResult->fetch_assoc()) {
              $postID = $postRow['id'];
              $authorID = $postRow['author_id'];
              
              $sqlAuthor = "SELECT * FROM `beta_users` WHERE `id`='$authorID'";
              $author = $conn->query($sqlAuthor);
              $authorRow = $author->fetch_assoc();

}
              echo $postRow['title'];
          ?>
