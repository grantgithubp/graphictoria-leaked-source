<?php
  include("../SiT_3/config.php");
  include("../SiT_3/header.php");
  
  if (isset($_GET['search'])) {
    echo '<head><title>\'' . $_GET['search'] . '\' Users - '.$sitename.'</title></head>';}
  else {
    echo '<head><title>Users - '.$sitename.'</title></head>';}
  
  if(isset($_GET['page'])) {$page = mysqli_real_escape_string($conn,intval($_GET['page']));} else {$page = 0;}
  $page = max($page,1);
?>

<?php
  include("../SiT_3/alert.php");
  ?>
 
<?php
$fetch_users = $conn->query("SELECT * FROM beta_users");
$total_users = mysqli_num_rows($fetch_users);



?>

<div class="containergrey_nopadding">
  <h4 class="banner_title">Browse users (<?php echo $total_users ?>)</h4><br>
  <center><form method="post">
<div class="field">
<input type="text" name="query" class="input" style="width: 100%;display: inline-block;" placeholder="Search">
</div>
</form></center>
    <table class="browse_users">
  <tr>
    <th>Avatar</th>
    <th>Name</th>
        <th>Badges</th>
  </tr>
      <?php
        if (isset($_GET['search'])) {
          $query = mysqli_real_escape_string($conn,strtolower($_GET['search']));
          
          $sqlCount = "SELECT * FROM `beta_users` WHERE  `usernameL` LIKE '%$query%' ORDER BY `username`";
          $countQ = $conn->query($sqlCount);
          $count = $countQ->num_rows;
          
          $page = min($page,max((int)($count/20),1));
  
          $limit = ($page-1)*20;
          
          $sqlSearch = "SELECT * FROM `beta_users` WHERE  `usernameL` LIKE '%$query%' ORDER BY `username` LIMIT $limit,20";
          $result = $conn->query($sqlSearch);
          echo '<table width="100%"cellspacing="0"cellpadding="4"border="0"style="background-color:#;"><tbody>';
          while($searchRow=$result->fetch_assoc()){
            $lastonline = time()-strtotime($searchRow['last_online']);
            echo '

              <a href="/user/' . $searchRow['id'] . '/">
<img src="/avatar/render/avatars/' . $searchRow['id'] . '.png?c='.$searchRow['avatar_id'].'" style="vertical-align:middle; width:69px;">
<b>' . htmlspecialchars($searchRow['username']) . '</b>';
            if ($lastonline >= 300) {
              $timedif = $lastonline . " seconds";
              if ($lastonline >= 300) {$timedif = (int)gmdate('i',$lastonline) . " minutes";}
              if ($lastonline >= 3600) {$timedif = (int)gmdate('H',$lastonline) . " hours";}
              if ($lastonline >= 86400) {$timedif = (int)gmdate('d',$lastonline) . " days";}
              if ($lastonline >= 2592000) {$timedif = (int)gmdate('m',$lastonline) . " months";}
              if ($lastonline >= 31536000) {$timedif = (int)gmdate('Y',$lastonline) . " years";}
              echo '<span style="float:right;" class="status-dot"></span></div>';}
            else {
              echo '<span style="float:right;" class="status-dot online"></span></div>';}
            if ($lastonline <= 300) {echo '';}
            else {echo '';}
            //echo'<span style="float:right;" class="status-dot"></span></div>';
            echo'
<span class="ellipsis">' . htmlspecialchars($searchRow['description']) . '</span>
</a>



';
            /*if ($lastonline >= 300) {
              $timedif = $lastonline . " seconds";
              if ($lastonline >= 300) {$timedif = (int)gmdate('i',$lastonline) . " minutes";}
              if ($lastonline >= 3600) {$timedif = (int)gmdate('H',$lastonline) . " hours";}
              if ($lastonline >= 86400) {$timedif = (int)gmdate('d',$lastonline) . " days";}
              if ($lastonline >= 2592000) {$timedif = (int)gmdate('m',$lastonline) . " months";}
              if ($lastonline >= 31536000) {$timedif = (int)gmdate('Y',$lastonline) . " years";}
              echo '<div style="text-align:center;"><span style="float:right;" class="status-dot "></span></span></div>';}
            else {
              echo '<div style="text-align:center;"><span style="float:right;" class="status-dot online "></span></div>';}
            if ($lastonline <= 300) {echo '<td style="text-align:center;"><i style="color:Green;font-size:15px;"</i></td>';}
            else {echo '<td style="text-align:center;"><i style="color:#DD0000;font-size:15px;" ></i></td>';}*/
          }
        }else{
                    $sqlCount = "SELECT * FROM `beta_users` ORDER BY `last_online` DESC";
                    $countQ = $conn->query($sqlCount);
                    $count = $countQ->num_rows;
                    $page = min($page,max((int)($count/20),1));
                    
                    $limit = ($page-1)*20;
                    
                    $sqlSearch = "SELECT * FROM `beta_users` ORDER BY `last_online` DESC LIMIT $limit,20";
                    $result = $conn->query($sqlSearch);
                    
                    echo '<table width="100%"cellspacing="0"cellpadding="4"border="0"style="background-color:#;"><tbody>';
          while($searchRow=$result->fetch_assoc()){
            $lastonline = time()-strtotime($searchRow['last_online']);
            echo '

              <a href="/user/' . $searchRow['id'] . '/">
<img src="/avatar/render/avatars/' . $searchRow['id'] . '.png?c='.$searchRow['avatar_id'].'" style="vertical-align:middle; width:100px;"> <b>' . $searchRow['username'] . '</b>
<br>';
            if ($lastonline >= 300) {
              $timedif = $lastonline . " seconds";
              if ($lastonline >= 300) {$timedif = (int)gmdate('i',$lastonline) . " minutes";}
              if ($lastonline >= 3600) {$timedif = (int)gmdate('H',$lastonline) . " hours";}
              if ($lastonline >= 86400) {$timedif = (int)gmdate('d',$lastonline) . " days";}
              if ($lastonline >= 2592000) {$timedif = (int)gmdate('m',$lastonline) . " months";}
              if ($lastonline >= 31536000) {$timedif = (int)gmdate('Y',$lastonline) . " years";}
              echo '<span style="float:right;" class="status-dot"></span>';}
            else {
              echo '<span style="float:right;" class="status-dot online"></span>';}
            if ($lastonline <= 300) {echo '';}
            else {echo '';}
            //echo'<span style="float:right;" class="status-dot"></span></div>';
            echo'
';
            
          }
          } echo '
            
           ';
        ?>
        <span>
        
        <?php
        if(isset($_GET['search'])) {
          echo '';
          if($page-2 > 0) {
              echo '<a style="color:#333;" href="?search='.$query.'&page=0">1</a> ... ';
          }
          if($count/20 > 1) {
                  for($i = max($page-2,0); $i < min($count/20,$page+2); $i++)
                  {
                    echo '<a class="page active" style="color:#333;" href="?search='.$query.'&page='.($i+1).'">'.($i+1).'</a> ';
                  }
                }
                if($count/20 > 4) {
                    echo '... <a class="page active" style="color:#333;" href="?search='.$query.'&page='.round($count/20).'">'.round($count/20).'</a> ';
                }
          
          echo '';
        }
        ?>
        
         
        
        
        </div>