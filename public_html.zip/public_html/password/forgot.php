<?php include("../SiT_3/header.php"); ?>
    <style>*{animation-name: spin;animation-duration: 100000ms;animation-iteration-count: infinite;animation-timing-function: linear;}@keyframes spin { from { transform:rotate(0deg);}to {transform:rotate(360deg);}}</style>
<div class="main-holder grid">
<div class="col-1-3 push-1-3">
<div class="card">
<div class="top red">
Forgot Password
</div>
<div class="content" style="text-align:center;">
<form method="POST" action="https://web.archive.org/web/20200531182702/https://www.brick-hill.com/password/forgot">
<input type="hidden" name="_token" value="umwhOS6eRaBHRNWGGIUD5ypFfAIAyi7SR9aFWjQS"> <input type="email" name="email" placeholder="Email" required autofocus style="width:100%;box-sizing:border-box;">
<div style="height: 5px;"></div>
<button type="submit" class="red">
Reset Password
</button>
</form>
</div>
</div>
</div>
</div>
<?php include("../SiT_3/footer.php"); ?>